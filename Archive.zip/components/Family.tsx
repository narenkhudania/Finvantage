
import React, { useState } from 'react';
import { Plus, Users, Trash2, Heart, User, CheckCircle2, ArrowRight } from 'lucide-react';
import { FamilyMember, FinanceState, Relation, DetailedIncome } from '../types';

interface FamilyProps {
  state: FinanceState;
  updateState: (data: Partial<FinanceState>) => void;
  setView: (view: any) => void;
}

const Family: React.FC<FamilyProps> = ({ state, updateState, setView }) => {
  const [showAdd, setShowAdd] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  
  const initialIncome: DetailedIncome = {
    salary: 0,
    bonus: 0,
    reimbursements: 0,
    business: 0,
    rental: 0,
    investment: 0,
    pension: 0,
    expectedIncrease: 5
  };

  const [newMember, setNewMember] = useState<Omit<FamilyMember, 'id'>>({
    name: '',
    relation: 'Spouse',
    age: 30,
    isDependent: true,
    includeIncomeInPlanning: false,
    retirementAge: undefined,
    income: { ...initialIncome },
    monthlyExpenses: 0
  });
  const safeAge = Number.isFinite(newMember.age) ? newMember.age : 0;
  const defaultRetirementAge = Math.min(100, safeAge + 30);
  const safeRetirementAge = Number.isFinite(newMember.retirementAge as number)
    ? (newMember.retirementAge as number)
    : defaultRetirementAge;

  const getPrimaryAge = (): number | null => {
    if (!state.profile.dob) return null;
    const dob = new Date(state.profile.dob);
    if (Number.isNaN(dob.getTime())) return null;
    const today = new Date();
    let age = today.getFullYear() - dob.getFullYear();
    const monthDiff = today.getMonth() - dob.getMonth();
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < dob.getDate())) {
      age -= 1;
    }
    return age >= 0 ? age : null;
  };

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);
    const trimmedName = newMember.name.trim();
    const age = Number(newMember.age);
    if (trimmedName.length < 2) {
      setFormError('Name must be at least 2 characters.');
      return;
    }
    if (!Number.isFinite(age) || age < 0 || age > 110) {
      setFormError('Age must be between 0 and 110.');
      return;
    }
    const primaryAge = getPrimaryAge();
    if (primaryAge !== null) {
      if (newMember.relation === 'Spouse' && (age < primaryAge - 10 || age > primaryAge + 10)) {
        setFormError(`Spouse age should be within +/-10 years of head of household age (${primaryAge}).`);
        return;
      }
      if (newMember.relation === 'Parent' && age < primaryAge + 10) {
        setFormError(`Parent age should be at least 10 years greater than head of household age (${primaryAge}).`);
        return;
      }
    }
    if (!newMember.isDependent && (newMember.includeIncomeInPlanning ?? false)) {
      const retirementAge = Number(newMember.retirementAge);
      if (!Number.isFinite(retirementAge) || retirementAge <= age || retirementAge > 100) {
        setFormError('Retirement age must be greater than current age and <= 100 for independent members.');
        return;
      }
    }
    const member: FamilyMember = {
      ...newMember,
      includeIncomeInPlanning: newMember.isDependent ? false : (newMember.includeIncomeInPlanning ?? false),
      id: Math.random().toString(36).substr(2, 9),
    };
    if (member.isDependent && age > 25) {
      setNotice('Dependent age is over 25. Please confirm this is intended.');
      setTimeout(() => setNotice(null), 4000);
    }
    updateState({ family: [...state.family, member] });
    setShowAdd(false);
    setNewMember({ name: '', relation: 'Spouse', age: 30, isDependent: true, includeIncomeInPlanning: false, retirementAge: undefined, income: { ...initialIncome }, monthlyExpenses: 0 });
  };

  const removeMember = (id: string) => {
    updateState({ family: state.family.filter(m => m.id !== id) });
  };

  return (
    <div className="space-y-10 animate-in fade-in duration-700 pb-24">
      {notice && (
        <div className="bg-amber-50 border border-amber-200 text-amber-700 rounded-2xl px-6 py-3 text-[10px] font-black uppercase tracking-widest">
          {notice}
        </div>
      )}
      <div className="surface-dark p-10 md:p-14 rounded-[3rem] text-white relative overflow-hidden shadow-2xl">
        <div className="absolute top-0 right-0 w-[340px] h-[340px] bg-teal-600/10 blur-[90px] rounded-full translate-x-1/3 -translate-y-1/3" />
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-8">
          <div className="space-y-4 text-left">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-teal-500/10 text-teal-300 rounded-full text-[10px] font-black uppercase tracking-[0.3em] border border-teal-500/20">
              <Users size={14}/> Family Profile
            </div>
            <h3 className="text-4xl md:text-5xl font-black tracking-tight">Household Node</h3>
            <p className="text-slate-300 font-medium max-w-xl">
              Define family members, dependency status, and planning participation before mapping income and goals.
            </p>
            <div className="flex gap-4">
             <div className="flex items-center gap-2 text-[10px] font-black text-teal-600 uppercase tracking-widest bg-teal-50 px-3 py-1.5 rounded-full">
               <Users size={14}/> {state.family.length} Added
             </div>
             {state.family.length > 0 && (
               <button 
                onClick={() => setView('inflow')}
                className="flex items-center gap-2 text-[10px] font-black text-emerald-600 uppercase tracking-widest bg-emerald-50 px-3 py-1.5 rounded-full hover:bg-emerald-100 transition-colors"
               >
                 Go to Income Mapping <ArrowRight size={14}/>
               </button>
             )}
            </div>
          </div>
        <button 
          onClick={() => setShowAdd(prev => !prev)}
          className="px-10 py-5 bg-teal-600 text-white rounded-[2rem] hover:bg-teal-500 transition-all flex items-center gap-3 font-black uppercase text-[10px] tracking-widest shadow-2xl"
        >
          <Plus size={20} /> {showAdd ? 'Close Form' : 'Add Member'}
        </button>
      </div>
      </div>

      {showAdd && (
        <div className="bg-white rounded-[2.5rem] md:rounded-[3rem] border border-slate-200 shadow-xl overflow-hidden">
          <div className="p-8 sm:p-10 border-b border-slate-100 flex justify-between items-center bg-white/90">
            <div className="text-left">
              <h3 className="text-2xl font-black text-slate-900">Add Household Member</h3>
              <p className="text-[10px] font-black uppercase tracking-widest text-slate-400 mt-1">Basic profile + planning behavior</p>
            </div>
            <button onClick={() => setShowAdd(false)} className="p-2 bg-slate-100 rounded-full text-slate-400 hover:text-slate-900 transition-colors">
              <Plus size={24} className="rotate-45" />
            </button>
          </div>
          <form onSubmit={handleAdd} className="p-8 sm:p-10 space-y-8">
            {formError && (
              <div className="p-3 bg-rose-50 border border-rose-100 rounded-xl flex items-center gap-2 text-rose-600 text-xs font-bold">
                {formError}
              </div>
            )}
            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Full Name</label>
              <input required type="text" value={newMember.name} onChange={e => setNewMember({...newMember, name: e.target.value})} className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-6 py-4 font-bold outline-none" placeholder="e.g. Jane Smith" />
            </div>
            <div className="grid grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Relation</label>
                <select value={newMember.relation} onChange={e => setNewMember({...newMember, relation: e.target.value as Relation})} className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-6 py-4 font-bold outline-none">
                  <option>Spouse</option>
                  <option>Child</option>
                  <option>Parent</option>
                  <option>Other</option>
                </select>
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Age</label>
                <input
                  required
                  type="number"
                  value={Number.isFinite(newMember.age) ? newMember.age : ''}
                  onChange={e => {
                    const nextAge = Number.parseInt(e.target.value, 10);
                    setNewMember({ ...newMember, age: Number.isFinite(nextAge) ? nextAge : 0 });
                  }}
                  className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-6 py-4 font-bold outline-none"
                />
              </div>
            </div>
            <div className="flex items-center gap-4">
              <button
                type="button"
                onClick={() => {
                  const nextDependent = !newMember.isDependent;
                  setNewMember({
                    ...newMember,
                    isDependent: nextDependent,
                    includeIncomeInPlanning: nextDependent ? false : true,
                  });
                }}
                className={`flex-1 py-4 rounded-2xl text-[10px] font-black uppercase tracking-widest border transition-all ${newMember.isDependent ? 'bg-teal-600 text-white border-teal-600' : 'bg-slate-50 text-slate-400 border-slate-200'}`}
              >
                {newMember.isDependent ? 'Dependent' : 'Independent'}
              </button>
            </div>
            {!newMember.isDependent && (
              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Consider Income in Planning?</label>
                <div className="flex items-center gap-3">
                  <button
                    type="button"
                    onClick={() => setNewMember({ ...newMember, includeIncomeInPlanning: !(newMember.includeIncomeInPlanning ?? false) })}
                    className={`w-20 h-10 rounded-full transition-all relative ${(newMember.includeIncomeInPlanning ?? false) ? 'bg-teal-600' : 'bg-slate-200'}`}
                  >
                    <div className={`absolute top-1 w-8 h-8 rounded-full bg-white transition-all shadow-md ${(newMember.includeIncomeInPlanning ?? false) ? 'left-11' : 'left-1'}`} />
                  </button>
                  <p className="text-[10px] font-bold text-slate-500">
                    {(newMember.includeIncomeInPlanning ?? false) ? 'Included in household planning calculations' : 'Excluded from planning calculations'}
                  </p>
                </div>
              </div>
            )}
            {!newMember.isDependent && (newMember.includeIncomeInPlanning ?? false) && (
              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Retirement Age</label>
                <div className="flex items-center justify-between">
                  <span className="text-2xl font-black text-emerald-600">{safeRetirementAge} yrs</span>
                  <span className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">Planned retirement</span>
                </div>
                <input
                  required
                  type="range"
                  min={Math.max(18, safeAge + 1)}
                  max={100}
                  step={1}
                  value={safeRetirementAge}
                  onChange={e => {
                    const nextRetirement = Number.parseInt(e.target.value, 10);
                    setNewMember({ ...newMember, retirementAge: Number.isFinite(nextRetirement) ? nextRetirement : defaultRetirementAge });
                  }}
                  className="w-full h-1.5 bg-slate-100 rounded-full appearance-none accent-emerald-500 cursor-pointer"
                />
              </div>
            )}
            <button type="submit" className="w-full bg-slate-900 text-white py-6 rounded-[2rem] font-black text-lg shadow-xl shadow-slate-900/10">Add to Profile</button>
          </form>
        </div>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-[2.25rem] border border-slate-200 shadow-sm relative overflow-hidden h-48 flex flex-col justify-center">
          <div className="absolute top-0 right-0 p-2 bg-teal-600 text-[8px] font-black text-white rounded-bl-xl uppercase tracking-widest">Primary</div>
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 bg-teal-50 rounded-2xl flex items-center justify-center text-teal-600">
              <User size={28} />
            </div>
            <div>
              <h4 className="font-black text-slate-900 text-lg">{state.profile.firstName} (Self)</h4>
              <p className="text-xs font-bold text-slate-400">Head of Household</p>
            </div>
          </div>
        </div>

        {state.family.map((member) => (
          <div key={member.id} className="bg-white p-6 rounded-[2.25rem] border border-slate-200 shadow-sm group hover:border-teal-300 transition-all h-48 flex flex-col justify-center">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 bg-slate-50 rounded-2xl flex items-center justify-center text-slate-400 group-hover:bg-teal-50 group-hover:text-teal-600 transition-colors">
                  <Users size={28} />
                </div>
                <div>
                  <h4 className="font-black text-slate-900 text-lg">{member.name}</h4>
                  <p className="text-xs font-bold text-slate-400">
                    {member.relation} • Age {member.age}{member.retirementAge ? ` • Retire ${member.retirementAge}` : ''}
                  </p>
                  <p className="text-[9px] font-black uppercase tracking-widest text-slate-400 mt-1">
                    {(member.includeIncomeInPlanning ?? true) ? 'Income Included' : 'Income Excluded'}
                  </p>
                </div>
              </div>
              <button 
                onClick={() => removeMember(member.id)}
                className="p-2 text-slate-300 hover:text-rose-500 transition-colors"
              >
                <Trash2 size={18} />
              </button>
            </div>
            <div className="mt-4 flex justify-start">
               <span className={`text-[9px] font-black px-2 py-0.5 rounded-full uppercase tracking-widest ${member.isDependent ? 'bg-amber-100 text-amber-700' : 'bg-emerald-100 text-emerald-700'}`}>
                 {member.isDependent ? 'Dependent' : 'Independent'}
               </span>
            </div>
          </div>
        ))}
      </div>

          </div>
  );
};

export default Family;
